package com.example.wgclient

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.launch

// Чёрная матовая палитра
private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF12141B)
private val PanelHi = Color(0xFF1B1E29)
private val Line = Color(0xFF292D3A)
private val Accent = Color(0xFF9B8CFF)
private val Good = Color(0xFF55D6A3)
private val Muted = Color(0xFF858A9B)
private val Bad = Color(0xFFFF6B78)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RentVpnApp() }
    }
}

@Composable
private fun RentVpnApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val state by VpnController.state.collectAsState()
    var config by remember { mutableStateOf(VpnController.loadConfig(context)) }
    var servers by remember { mutableStateOf(VpnController.parseSubscription(VpnController.loadSub(context))) }
    var selected by remember { mutableIntStateOf(-1) }
    var profileName by remember { mutableStateOf("Мой профиль") }
    var importUrl by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val connected = state == Tunnel.State.UP

    fun applySubscription(text: String) {
        val list = VpnController.parseSubscription(text)
        if (list.isEmpty()) { message = "Не удалось распознать подписку"; return }
        servers = list
        VpnController.saveSub(context, text)
        val firstOk = list.indexOfFirst { it.supported }
        if (firstOk >= 0) {
            selected = firstOk; config = list[firstOk].raw
            VpnController.saveConfig(context, config); profileName = list[firstOk].name
        } else selected = -1
        message = "Серверов: ${list.size}, доступно для подключения: ${list.count { it.supported }}"
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                busy = true
                runCatching { VpnController.saveConfig(context, config); VpnController.connect(context, config) }
                    .onFailure { message = "Не удалось подключиться: ${it.message ?: "проверьте конфигурацию"}" }
                busy = false
            }
        } else message = "Разрешение Android VPN не выдано"
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching { readText(context, uri) }
            .onSuccess { applySubscription(it) }
            .onFailure { message = "Не удалось прочитать файл" }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, onPrimary = Bg, secondary = Accent, background = Bg, surface = Panel,
        onSurface = Color.White, onBackground = Color.White, outline = Line
    )) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(16.dp)).background(PanelHi).border(1.dp, Line, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text("R", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("RENT VPN", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("PRIVATE CONNECTION", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Box(Modifier.clip(CircleShape).background(Panel).border(1.dp, Line, CircleShape).padding(horizontal = 12.dp, vertical = 7.dp)) {
                    Text(if (connected) "● ONLINE" else "● OFFLINE", color = if (connected) Good else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(connected, config, profileName, message, busy,
                        onConnect = {
                            if (connected) scope.launch { runCatching { VpnController.disconnect(context) }.onFailure { message = it.message ?: "Ошибка отключения" } }
                            else if (config.isBlank()) message = "Сначала добавьте подписку или WireGuard-конфигурацию"
                            else {
                                val intent = GoBackend.VpnService.prepare(context)
                                if (intent != null) permissionLauncher.launch(intent) else scope.launch {
                                    busy = true
                                    runCatching { VpnController.saveConfig(context, config); VpnController.connect(context, config) }
                                        .onFailure { message = "Ошибка: ${it.message ?: "неверная конфигурация"}" }
                                    busy = false
                                }
                            }
                        }, onServers = { tab = 1 })
                    1 -> ServersScreen(
                        profile = profileName, config = config, url = importUrl, servers = servers, selected = selected,
                        onName = { profileName = it }, onConfig = { config = it }, onUrl = { importUrl = it },
                        onFile = { filePicker.launch(arrayOf("*/*")) },
                        onPaste = { clipboard.getText()?.text?.let { applySubscription(it) } ?: run { message = "Буфер обмена пуст" } },
                        onFetch = {
                            scope.launch {
                                busy = true
                                runCatching { VpnController.fetchText(importUrl) }
                                    .onSuccess { applySubscription(it) }
                                    .onFailure { message = "Не удалось загрузить: ${it.message ?: "ошибка сети"}" }
                                busy = false
                            }
                        },
                        onPick = { i ->
                            val s = servers[i]
                            if (s.supported) { selected = i; config = s.raw; profileName = s.name; VpnController.saveConfig(context, config); message = "Выбран: ${s.name}" }
                            else message = "Протокол ${s.protocol.uppercase()} пока не поддерживается в этой версии"
                        },
                        message = message, busy = busy)
                    else -> SettingsScreen(onClear = {
                        config = ""; servers = emptyList(); selected = -1
                        VpnController.saveConfig(context, ""); VpnController.saveSub(context, "")
                        message = "Локальные данные удалены"
                    })
                }
            }
            Row(Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavItem("⌂", "Главная", tab == 0) { tab = 0 }
                NavItem("◎", "Серверы", tab == 1) { tab = 1 }
                NavItem("⚙", "Настройки", tab == 2) { tab = 2 }
            }
        }
    }
}

@Composable
private fun HomeScreen(connected: Boolean, config: String, profile: String, message: String, busy: Boolean, onConnect: () -> Unit, onServers: () -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(250.dp).clip(CircleShape).background(Panel).border(1.dp, if (connected) Good.copy(alpha = .6f) else Line, CircleShape).padding(18.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (connected) "VPN ВКЛЮЧЁН" else "VPN ВЫКЛЮЧЕН", color = if (connected) Good else Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = onConnect, enabled = !busy, modifier = Modifier.size(120.dp), shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = if (connected) PanelHi else Accent, contentColor = if (connected) Color.White else Bg)) {
                    Text(if (busy) "..." else if (connected) "Ⅱ" else "⏻", fontSize = 40.sp)
                }
                Spacer(Modifier.height(9.dp))
                Text(if (connected) "НАЖМИТЕ, ЧТОБЫ ОТКЛЮЧИТЬ" else "НАЖМИТЕ, ЧТОБЫ ВКЛЮЧИТЬ", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            }
        }
        Spacer(Modifier.height(26.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(22.dp)).clickable { onServers() }.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("◈", color = Accent, fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Текущий сервер", color = Muted, fontSize = 11.sp)
                Text(if (config.isBlank()) "Не выбран" else profile, color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Text("Изменить  ›", color = Accent, fontSize = 11.sp)
        }
        if (message.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(message, color = if (message.contains("Ошибка") || message.contains("Не удалось") || message.contains("не поддерж")) Bad else Good, fontSize = 12.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ServersScreen(
    profile: String, config: String, url: String, servers: List<VpnController.Server>, selected: Int,
    onName: (String) -> Unit, onConfig: (String) -> Unit, onUrl: (String) -> Unit,
    onFile: () -> Unit, onPaste: () -> Unit, onFetch: () -> Unit, onPick: (Int) -> Unit,
    message: String, busy: Boolean
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ПОДПИСКА И СЕРВЕРЫ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = url, onValueChange = onUrl, label = { Text("Ссылка подписки (HTTPS / happ://add/)") }, placeholder = { Text("https://…") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = onFetch, enabled = (url.startsWith("https://") || url.startsWith("happ://add/")) && !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Загрузка…" else "Добавить подписку") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onFile, modifier = Modifier.weight(1f)) { Text("Из файла", color = Accent) }
            OutlinedButton(onClick = onPaste, modifier = Modifier.weight(1f)) { Text("Из буфера", color = Accent) }
        }
        if (message.isNotBlank()) Text(message, color = if (message.contains("не поддерж") || message.contains("Не удалось")) Bad else Good, fontSize = 12.sp)

        if (servers.isNotEmpty()) {
            Text("СЕРВЕРЫ (${servers.size})", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            servers.forEachIndexed { i, s ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(if (i == selected) PanelHi else Panel)
                    .border(1.dp, if (i == selected) Accent.copy(alpha = .6f) else Line, RoundedCornerShape(14.dp))
                    .clickable { onPick(i) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, color = if (s.supported) Color.White else Muted, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(s.protocol.uppercase() + if (s.supported) "" else " · не поддерживается", color = Muted, fontSize = 11.sp)
                    }
                    if (i == selected) Text("✓", color = Good, fontSize = 18.sp)
                }
            }
        }

        Text("WIREGUARD CONFIG (ВРУЧНУЮ)", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        OutlinedTextField(value = config, onValueChange = onConfig, modifier = Modifier.fillMaxWidth().height(200.dp),
            placeholder = { Text("[Interface]\nPrivateKey = …\nAddress = …\n\n[Peer]\nPublicKey = …\nEndpoint = …") },
            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp))
        Text("Данные хранятся только на устройстве. Не передавайте свой PrivateKey другим людям.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingsScreen(onClear: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("НАСТРОЙКИ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        SettingRow("Приложение", "RENT VPN · версия 1.1")
        SettingRow("Подключение", "WireGuard (VLESS и др. — только в списке)")
        SettingRow("Хранение", "Локально на устройстве")
        OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("Удалить сохранённые данные", color = Bad) }
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(value, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable { onClick() }.padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = if (selected) Accent else Muted, fontSize = 22.sp)
        Text(label, color = if (selected) Color.White else Muted, fontSize = 10.sp)
    }
}

private fun readText(context: Context, uri: Uri): String = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
