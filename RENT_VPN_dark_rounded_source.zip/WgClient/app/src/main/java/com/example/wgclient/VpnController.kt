package com.example.wgclient

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import android.util.Base64
import java.io.File
import java.net.URLDecoder
import java.net.HttpURLConnection
import java.net.URL

/** Управление WireGuard-туннелем и локальной конфигурацией. */
object VpnController {
    private var backend: GoBackend? = null
    private val _state = MutableStateFlow(Tunnel.State.DOWN)
    val state: StateFlow<Tunnel.State> = _state
    private val tunnel = object : Tunnel {
        override fun getName(): String = "rentvpn"
        override fun onStateChange(newState: Tunnel.State) { _state.value = newState }
    }
    private fun backend(context: Context): GoBackend = backend ?: GoBackend(context.applicationContext).also { backend = it }

    suspend fun connect(context: Context, configText: String) = withContext(Dispatchers.IO) {
        require(configText.contains("[Interface]") && configText.contains("[Peer]")) { "Ожидается WireGuard-конфигурация с [Interface] и [Peer]" }
        val config = Config.parse(configText.byteInputStream())
        backend(context).setState(tunnel, Tunnel.State.UP, config)
    }
    suspend fun disconnect(context: Context) = withContext(Dispatchers.IO) { backend(context).setState(tunnel, Tunnel.State.DOWN, null) }
    private fun file(context: Context) = File(context.filesDir, "rentvpn-tunnel.conf")
    fun loadConfig(context: Context): String = file(context).takeIf { it.exists() }?.readText().orEmpty()
    fun saveConfig(context: Context, text: String) { file(context).writeText(text) }

    /** Загружает текстовый WireGuard-конфиг по HTTPS. */
    suspend fun fetchConfig(address: String): String = withContext(Dispatchers.IO) {
        require(address.startsWith("https://")) { "Разрешены только HTTPS-ссылки" }
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 12000
            requestMethod = "GET"
            instanceFollowRedirects = true
        }
        try {
            require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            require(text.length <= 1024 * 1024) { "Файл слишком большой" }
            require(text.contains("[Interface]") && text.contains("[Peer]")) { "Ссылка не вернула WireGuard-конфигурацию" }
            text
        } finally { connection.disconnect() }
    }

    // ---------- Подписки ----------
    data class Server(val name: String, val protocol: String, val raw: String) {
        val supported: Boolean get() = protocol == "wireguard"
    }

    private fun subFile(context: Context) = File(context.filesDir, "subscription.txt")
    fun loadSub(context: Context): String = subFile(context).takeIf { it.exists() }?.readText().orEmpty()
    fun saveSub(context: Context, text: String) { subFile(context).writeText(text) }

    /** Скачивает подписку (любой текст) по HTTPS. */
    suspend fun fetchText(address: String): String = withContext(Dispatchers.IO) {
        var url = address.trim()
        // ссылки вида happ://add/https://...
        if (url.startsWith("happ://add/")) url = url.removePrefix("happ://add/")
        require(url.startsWith("https://")) { "Нужна HTTPS-ссылка подписки" }
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "RentVPN/1.0")
            instanceFollowRedirects = true
        }
        try {
            require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            require(text.length <= 2 * 1024 * 1024) { "Ответ слишком большой" }
            require(text.isNotBlank()) { "Подписка пустая" }
            text
        } finally { connection.disconnect() }
    }

    /** Разбирает подписку: WireGuard-конфиг, base64-список или обычный список ссылок. */
    fun parseSubscription(input: String): List<Server> {
        var text = input.trim()
        if (text.contains("[Interface]") && text.contains("[Peer]")) {
            return listOf(Server("WireGuard", "wireguard", text))
        }
        if (!text.contains("://")) {
            text = runCatching {
                String(Base64.decode(text.filter { !it.isWhitespace() }, Base64.DEFAULT or Base64.URL_SAFE))
            }.getOrDefault(text)
        }
        return text.lines().map { it.trim() }
            .filter { it.contains("://") && !it.startsWith("#") }
            .map { line ->
                val proto = line.substringBefore("://").lowercase()
                val name = line.substringAfter("#", "").let {
                    if (it.isBlank()) proto.uppercase() else runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it)
                }
                Server(name, proto, line)
            }
    }
}
